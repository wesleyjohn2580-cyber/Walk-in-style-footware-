WALK IN STYLE LADIES FOOTWARE - starter shop

Run locally:
1. Install Python 3.
2. In this folder run: pip install -r requirements.txt
3. Run: python app.py
4. Open http://127.0.0.1:5000/
5. Admin products: http://127.0.0.1:5000/admin/products

The SQLite database is shop.sqlite. Product images are stored in static/uploads.
Before public deployment, change app.secret_key and add proper admin login/authentication.
