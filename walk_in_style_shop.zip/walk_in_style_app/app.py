from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'shop.sqlite')
UPLOAD = os.path.join(BASE, 'static', 'uploads')
os.makedirs(UPLOAD, exist_ok=True)
app = Flask(__name__)
app.secret_key = 'change-this-secret-key'


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

@app.route('/')
def shop():
    con=db(); products=con.execute('SELECT * FROM products ORDER BY date_added DESC').fetchall(); con.close()
    return render_template('shop.html', products=products)

@app.route('/admin/products')
def products_admin():
    con=db(); products=con.execute('SELECT * FROM products ORDER BY date_added DESC').fetchall(); con.close()
    return render_template('admin_products.html', products=products)

@app.route('/admin/products/add', methods=['GET','POST'])
def add_product():
    if request.method == 'POST':
        name=request.form['product_name'].strip(); pid=request.form['product_id'].strip(); category=request.form.get('category','').strip()
        price=float(request.form.get('price_ghs') or 0); sizes=request.form.get('sizes','').strip(); colour=request.form.get('colour','').strip()
        qty=int(request.form.get('quantity') or 0); desc=request.form.get('description','').strip(); status=request.form.get('availability','In Stock')
        image=request.files.get('image'); image_name=''
        if image and image.filename:
            image_name=secure_filename(image.filename); image.save(os.path.join(UPLOAD,image_name))
        con=db()
        con.execute('''INSERT INTO products(product_id,product_name,category,price_ghs,sizes,colour,quantity,image_path,description,availability) VALUES(?,?,?,?,?,?,?,?,?,?)''',
                    (pid,name,category,price,sizes,colour,qty,image_name,desc,status))
        con.commit(); con.close(); flash('Product added successfully.'); return redirect(url_for('products_admin'))
    return render_template('add_product.html')

if __name__ == '__main__':
    app.run(debug=True)
